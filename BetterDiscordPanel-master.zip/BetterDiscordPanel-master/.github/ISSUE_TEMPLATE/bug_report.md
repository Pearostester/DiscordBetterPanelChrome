---
name: Bug report
about: Here you can create a bug report. If you would like to report a bug through Discord, join the official BetterDiscordPanel server here. https://discord.gg/5SAVPAj
title: "[BUG]"
labels: Bug
assignees: ''

---

#### How major is the bug from 1 - 10
- Scale: 

#### What type of bug is it?
- Type: 

#### Steps required to reproduce the bug
- Steps:

#### Screenshot (In most cases required)
- Screenshot:

