# How to contribute to BetterDiscordPanel

## 1. Fork the Repository 

![fork](../assets/images/contribution/fork.png)

## 2. Make your changes

![changes](../assets/images/contribution/upload.png)

## 3. Make a pull request

![pr](../assets/images/contribution/create_pull.png)

***

#### If you encounter any problems, please create a new issue.
